@echo off
taskkill /F /IM AuraLauncher.exe >nul 2>&1
echo Aura Launcher stopped.
pause
