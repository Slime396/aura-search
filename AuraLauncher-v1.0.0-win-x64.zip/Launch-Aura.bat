@echo off
start "" "%~dp0AuraLauncher.exe"
